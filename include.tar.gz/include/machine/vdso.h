/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/vdso.h 237433 2012-06-22 07:06:40Z kib $ */

#include <x86/vdso.h>
