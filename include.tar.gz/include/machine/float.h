/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/float.h 232491 2012-03-04 14:00:32Z tijl $ */

#include <x86/float.h>
