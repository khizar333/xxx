/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/ofw_machdep.h 250840 2013-05-21 03:05:49Z marcel $ */

#include <x86/ofw_machdep.h>
