/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/pvclock.h 278183 2015-02-04 08:26:43Z bryanv $ */

#include <x86/pvclock.h>
