/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/acpica_machdep.h 254305 2013-08-13 22:05:10Z jkim $ */

#include <x86/acpica_machdep.h>
