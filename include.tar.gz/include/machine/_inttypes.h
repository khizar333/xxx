/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/_inttypes.h 217157 2011-01-08 18:09:48Z tijl $ */

#include <x86/_inttypes.h>
