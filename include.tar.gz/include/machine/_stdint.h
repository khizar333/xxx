/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/_stdint.h 232264 2012-02-28 18:38:33Z tijl $ */

#include <x86/_stdint.h>
