/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/cputypes.h 308433 2016-11-08 06:13:22Z jhb $ */

#include <x86/cputypes.h>
