/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/pci_cfgreg.h 223440 2011-06-22 21:04:13Z jhb $ */

#include <x86/pci_cfgreg.h>
