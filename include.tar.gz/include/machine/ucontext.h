/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/ucontext.h 247047 2013-02-20 17:39:52Z kib $ */

#include <x86/ucontext.h>
