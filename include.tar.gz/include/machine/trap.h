/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/trap.h 232492 2012-03-04 14:12:57Z tijl $ */

#include <x86/trap.h>
