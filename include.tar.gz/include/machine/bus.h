/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/bus.h 244191 2012-12-13 21:27:20Z jimharris $ */

#include <x86/bus.h>
