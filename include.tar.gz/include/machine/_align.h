/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/_align.h 215856 2010-11-26 10:59:20Z tijl $ */

#include <x86/_align.h>
