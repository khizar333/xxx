/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/_limits.h 232262 2012-02-28 18:24:28Z tijl $ */

#include <x86/_limits.h>
