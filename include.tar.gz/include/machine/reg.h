/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/reg.h 233124 2012-03-18 19:06:38Z tijl $ */

#include <x86/reg.h>
