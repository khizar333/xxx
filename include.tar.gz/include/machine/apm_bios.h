/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/apm_bios.h 215140 2010-11-11 19:36:21Z jkim $ */

#include <x86/apm_bios.h>
