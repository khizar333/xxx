/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/stdarg.h 232276 2012-02-28 22:30:58Z tijl $ */

#include <x86/stdarg.h>
