/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/dump.h 276772 2015-01-07 01:01:39Z markj $ */

#include <x86/dump.h>
