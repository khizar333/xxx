/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/_types.h 232261 2012-02-28 18:15:28Z tijl $ */

#include <x86/_types.h>
