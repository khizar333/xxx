/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/endian.h 232266 2012-02-28 19:39:54Z tijl $ */

#include <x86/endian.h>
