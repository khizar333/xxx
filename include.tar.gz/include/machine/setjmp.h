/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/setjmp.h 232275 2012-02-28 22:17:52Z tijl $ */

#include <x86/setjmp.h>
