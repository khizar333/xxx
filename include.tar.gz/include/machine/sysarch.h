/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/sysarch.h 233209 2012-03-19 21:57:31Z tijl $ */

#include <x86/sysarch.h>
