/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/ptrace.h 232520 2012-03-04 20:24:28Z tijl $ */

#include <x86/ptrace.h>
