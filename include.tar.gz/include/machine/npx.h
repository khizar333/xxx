/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/npx.h 233044 2012-03-16 20:24:30Z tijl $ */

#include <x86/fpu.h>
