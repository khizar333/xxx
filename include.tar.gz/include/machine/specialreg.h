/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/specialreg.h 233207 2012-03-19 21:34:11Z tijl $ */

#include <x86/specialreg.h>
