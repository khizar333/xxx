/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/11.3/sys/amd64/include/metadata.h 293343 2016-01-07 19:47:26Z emaste $ */

#include <x86/metadata.h>
